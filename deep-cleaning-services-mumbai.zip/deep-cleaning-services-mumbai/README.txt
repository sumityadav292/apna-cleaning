DEEP CLEANING SERVICES MUMBAI
Premium PHP website | cPanel / shared-hosting package
====================================================

1) REQUIREMENTS
- PHP 8.0 or newer (8.1+ recommended)
- Apache hosting with PHP enabled
- mod_rewrite recommended for /services and /blog clean URLs
- No Node.js, Composer or database is required for this version
- PHP mail() must be enabled by the hosting provider before enquiries can be emailed

2) UPLOAD / INSTALL
1. Download and extract this ZIP on your computer.
2. Upload the CONTENTS of the deep-cleaning-services-mumbai folder to the domain document root (commonly public_html/).
3. Confirm index.php is directly inside the document root.
4. Open config/config.php and check base_url. It is currently set to:
   https://www.deepcleaningservices.co
5. Visit the website over HTTPS.
6. If clean URLs do not work, check that Apache mod_rewrite is enabled. The standard hosting .htaccess can be adjusted by the host. If installing in a subfolder, update RewriteBase in .htaccess to that folder path (for example /demo/).

3) IMPORTANT: VERIFY BUSINESS DETAILS BEFORE GOING LIVE
The supplied brief explicitly says the phone numbers and email addresses need confirmation. They are stored in config/config.php but NOT displayed publicly by default.

Open config/config.php and only after the business confirms the correct details:
- Set contact_details_confirmed to true.
- Remove incorrect entries from phones_pending_confirmation and emails_pending_confirmation.
- The code currently displays all entries in those arrays once the confirmation flag is true. Keep only the numbers and email addresses that have been approved.
- Set lead_recipient to the confirmed inbox that should receive enquiries.
- Set lead_from to a valid mailbox on this domain if the host recommends it (for better mail deliverability).
- Set lead_form_enabled to true after testing mail delivery.

Example (illustrative configuration only, do not copy until verified):
'contact_details_confirmed' => true,
'phones_pending_confirmation' => ['+91 ...'],
'emails_pending_confirmation' => ['name@example.com'],
'lead_recipient' => 'confirmed-inbox@example.com',
'lead_from' => 'website@your-domain.example',
'lead_form_enabled' => true,

After enabling the form, send a test enquiry. Check inbox and spam. Ask your hosting provider to configure SPF/DKIM and the recommended SMTP/mail settings. The built-in form uses PHP mail(); some hosts block or restrict this function. A transactional SMTP integration can be added later if needed.

4) SERVICES ARE NOT PUBLISHED UNTIL APPROVED
The prompt lists possible categories but explicitly says these are proposed, not confirmed. Therefore approved_services is empty and no service-specific cards or detail pages are advertised by default.

To publish a confirmed service, add an entry to approved_services in config/config.php. Example structure:
'approved_services' => [
  'example-service' => [
    'title' => 'Confirmed service name',
    'icon' => 'fa-sparkles',
    'description' => 'Original description approved by the business.',
    'image' => 'https://images.unsplash.com/your-approved-image-url'
  ]
],

Use a lowercase slug with letters, numbers and hyphens. The Services overview, navigation dropdown and /services/{slug} detail route use this central array. Do not add any category until the business confirms it is offered.

5) CONTENT / TRUST SAFEGUARDS
- No customer testimonials, review scores or customer names have been fabricated. The homepage uses an explicit review-pending placeholder.
- Gallery imagery is illustrative stock photography, not represented as completed work by this business. Replace with genuine, permission-cleared business photographs when available.
- Blog content is original general guidance. It does not claim that the business provides a specific service.
- The address and working hours are displayed from the user's supplied project brief. Verify them before launch if they have changed.
- Social URLs are empty by default; add only official profile URLs in social_links in config/config.php.
- The temporary logo and social preview graphic are generated SVG placeholders because no logo image file was included with the text prompt. Replace assets/images/logo.svg and favicon.svg with the approved brand artwork before launch.
- The two inspiration websites were unavailable during this build, so no claims are made about having inspected their exact designs. No copy or business data was taken from them.

6) BRAND / CONTACT CONFIGURATION
All primary settings are in config/config.php. Do not put private credentials in publicly accessible files. config/, includes/ and storage/ have deny-access .htaccess files. Keep these protections when deploying on Apache.

7) FORMS AND SECURITY
- Contact form is disabled until contact_details_confirmed, lead_form_enabled and a valid lead_recipient are set.
- CSRF token validation, basic honeypot spam field, server-side validation, email-header newline checks, session-based one-minute submission throttle and output escaping are included.
- The form is stateless and does not store enquiries in a database.
- Use HTTPS in production. Confirm PHP sessions are enabled.
- If the host does not support .htaccess directives or mod_headers/mod_expires, ask the host to adapt them. Do not remove config/includes/storage access protection without an equivalent server-level rule.

8) SEO
- Page-specific title and description metadata, canonical URLs, Open Graph tags, local business structured data, robots.txt and sitemap.xml are included.
- Update sitemap.xml when new approved pages/posts are added, then submit https://www.deepcleaningservices.co/sitemap.xml in Google Search Console.
- The map embed uses the supplied business address as a map query and should be checked for pin accuracy before launch.
- Review page copy and legal drafts with the business. Privacy Policy and Terms are starter drafts, not legal advice; complete them with the actual data-handling, pricing, cancellation and service terms before publication.

9) EXTERNAL ASSETS / PERFORMANCE
- Design typography uses Google Fonts (DM Sans and Manrope).
- Icons use Font Awesome CDN.
- Illustrative photos are remote Unsplash images; internet access is needed for these photos to load. For best performance and long-term control, download licensed/permission-cleared images, convert to WebP/AVIF and update the image URLs.
- Main layout, responsive styling and interactions are local in assets/css/style.css and assets/js/main.js.
- Reduced-motion preferences are supported. Three.js and heavy animation libraries are intentionally not added because the CSS/JS treatment is lighter and more appropriate for shared hosting.

10) FILE MAP
index.php                 Homepage
about.php                 About page
services.php              Services overview (approved services only)
services/detail.php       Individual service template
gallery.php               Photo gallery and lightbox
why-choose-us.php         Why choose us
qna.php                   FAQ / Q&A
contact.php               Contact and quotation enquiry
contact-submit.php        Secure form handler
blog/index.php            Blog listing
blog/post.php             Blog detail template
privacy-policy.php        Privacy draft
terms.php                 Terms draft
404.php                   Custom not-found page
includes/                 Shared header, footer, helpers
config/                   Central configuration
assets/css/style.css      Premium responsive theme
assets/js/main.js         Navigation, reveal, FAQ, lightbox and form UX
assets/images/            Temporary SVG brand and social graphics
.htaccess                 Clean URLs and basic response headers
robots.txt / sitemap.xml  Search-engine discovery

END OF README
