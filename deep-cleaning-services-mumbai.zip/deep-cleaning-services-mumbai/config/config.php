
<?php
/** Central configuration for Deep Cleaning Services Mumbai. */

$config = [
    'business_name' => 'Deep Cleaning Services Mumbai',
    'tagline' => 'A Clean Mumbai is a Green Mumbai.',

    // Local development URL. Change this when deploying to the live domain.
    'base_url' => 'http://localhost/deep-cleaning-services-mumbai',

    'city' => 'Mumbai',
    'state' => 'Maharashtra',

    'address' => '116/924, 1st Floor, Best Colony Road, Motilal Nagar 1, Goregaon West, Mumbai, Maharashtra 400104',

    'working_hours' => 'Monday - Sunday: 8:00 AM - 8:00 PM',
    'opening_hours_schema' => 'Mo-Su 08:00-20:00',

    // Contact details confirmed by the business.
    'contact_details_confirmed' => true,

    'phone' => '+91 99674 49586',
    'phone_link' => '+919967449586',
    'whatsapp' => '919967449586',
    'email' => 'info@deepcleaningservices.co',

    // Keep only the confirmed contact details.
    'phones_pending_confirmation' => [
        '+91 99674 49586'
    ],

    'emails_pending_confirmation' => [
        'info@deepcleaningservices.co'
    ],

    // Website enquiry form settings.
    'lead_recipient' => 'info@deepcleaningservices.co',
    'lead_from' => 'info@deepcleaningservices.co',
    'lead_form_enabled' => true,

    'approved_services' => [
        'full-home-deep-cleaning' => [
            'title' => 'Full Home Deep Cleaning'
        ],
        'sofa-cleaning' => [
            'title' => 'Sofa Cleaning'
        ],
        'carpet-cleaning' => [
            'title' => 'Carpet Cleaning'
        ],
        'kitchen-deep-cleaning' => [
            'title' => 'Kitchen Deep Cleaning'
        ],
        'bathroom-deep-cleaning' => [
            'title' => 'Bathroom Deep Cleaning'
        ],
        'floor-cleaning-polishing' => [
            'title' => 'Floor Cleaning & Polishing'
        ],
        'office-deep-cleaning' => [
            'title' => 'Office Deep Cleaning'
        ],
        'commercial-cleaning' => [
            'title' => 'Commercial Cleaning'
        ],
        'residential-cleaning' => [
            'title' => 'Residential Cleaning'
        ],
        'water-tank-cleaning' => [
            'title' => 'Water Tank Cleaning'
        ],
        'upholstery-cleaning' => [
            'title' => 'Upholstery Cleaning'
        ],
        'specialized-cleaning' => [
            'title' => 'Specialized Cleaning'
        ],
    ],

    'social_links' => [],

    'map_embed' => 'https://www.google.com/maps?q=116%2F924%2C%201st%20Floor%2C%20Best%20Colony%20Road%2C%20Motilal%20Nagar%201%2C%20Goregaon%20West%2C%20Mumbai%2C%20Maharashtra%20400104&output=embed',
];
