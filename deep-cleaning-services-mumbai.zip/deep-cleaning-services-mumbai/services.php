
<?php
require_once __DIR__.'/includes/bootstrap.php';

$pageTitle = 'Deep Cleaning Services in Mumbai | Our Services';
$pageDescription = 'Explore home, sofa, carpet, kitchen, bathroom, office and other cleaning service information in Mumbai.';

$services = approved_services();

$serviceImages = [
    'full-home-deep-cleaning' =>
        'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=1000&q=85',

    'sofa-cleaning' =>
        'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1000&q=85',

    'carpet-cleaning' =>
        'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1000&q=85',

    'kitchen-deep-cleaning' =>
        'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1000&q=85',

    'bathroom-deep-cleaning' =>
        'https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=1000&q=85',

    'floor-cleaning-polishing' =>
        'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1000&q=85',

    'office-deep-cleaning' =>
        'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1000&q=85',

    'commercial-cleaning' =>
        'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=1000&q=85',

    'residential-cleaning' =>
        'https://images.unsplash.com/photo-1600210492493-0946911123ea?auto=format&fit=crop&w=1000&q=85',

    
    'water-tank-cleaning' => 'https://www.pluspoint.ae/uploads/Blogs/blog_1304724368.webp',

    'upholstery-cleaning' =>
        'https://images.unsplash.com/photo-1550254478-ead40cc54513?auto=format&fit=crop&w=1000&q=85',

    'specialized-cleaning' =>
        'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&w=1000&q=85',
];

require __DIR__.'/includes/header.php';
?>

<section class="page-hero page-hero-compact">
    <div class="page-hero-image"
         style="background-image:url('https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&w=1800&q=85')">
    </div>
    <div class="page-hero-overlay"></div>

    <div class="container page-hero-content">
        <div class="eyebrow eyebrow-light">
            <span></span> OUR CLEANING SERVICES
        </div>

        <h1>Cleaning solutions for <em>every space.</em></h1>

        <p>
            Explore our cleaning service categories and find the right
            information for your home or workplace in Mumbai.
        </p>

        <div class="breadcrumbs">
            <a href="<?=e(site_url())?>">Home</a>
            <i class="fa-solid fa-angle-right"></i>
            <span>Services</span>
        </div>
    </div>
</section>

<section class="section services-catalogue-section">
    <div class="container">

        <div class="section-heading centered services-catalogue-heading reveal">
            <div class="eyebrow">
                <span></span> PROFESSIONAL CLEANING SOLUTIONS
            </div>

            <h2>Explore our complete range of <em>cleaning services.</em></h2>

            <p>
                From residential spaces to offices and commercial properties,
                explore our service categories and learn more about the
                cleaning requirements, process and available options.
            </p>
        </div>

        <?php if($services): ?>

        <div class="approved-service-grid services-catalogue-grid">

            <?php foreach($services as $slug => $s): ?>

            <?php
                $serviceTitle = $s['title'] ?? 'Cleaning Service';

                $serviceSummary = $s['summary'] ??
                    'Explore cleaning information, service details and requirements.';

                $image = $serviceImages[$slug] ??
                    'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&w=1000&q=85';
            ?>

            <article class="approved-service-card services-catalogue-card">

                <a class="service-card-image"
                   href="<?=e(page_url('services/'.rawurlencode($slug)))?>"
                   aria-label="<?=e($serviceTitle)?> details">

                    <img
                        src="<?=e($image)?>"
                        alt="<?=e($serviceTitle)?> in Mumbai"
                        loading="lazy"
                        decoding="async"
                        referrerpolicy="no-referrer">

                    <span class="service-card-image-label">
                        <i class="fa-solid fa-sparkles"></i>
                        CLEANING SOLUTIONS
                    </span>
                </a>

                <div class="service-card-content">

                    <span class="service-card-kicker">
                        <i class="fa-solid fa-circle-check"></i>
                        OUR SERVICES
                    </span>

                    <h3>
                        <?=e($serviceTitle)?>
                    </h3>

                    <p>
                        <?=e($serviceSummary)?>
                    </p>

                    <a class="service-card-link"
                       href="<?=e(page_url('services/'.rawurlencode($slug)))?>">
                        Explore Service
                        <i class="fa-solid fa-arrow-right"></i>
                    </a>

                </div>
            </article>

            <?php endforeach; ?>

        </div>

        <?php else: ?>

        <div class="catalogue-pending">
            <h3>Service information is being updated.</h3>
            <p>Please contact us to discuss your cleaning requirements.</p>
            <a class="button button-primary"
               href="<?=e(page_url('contact.php'))?>">
                Contact Us
                <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>

        <?php endif; ?>

    </div>
</section>

<section class="section section-soft">
    <div class="container">

        <div class="section-heading centered">
            <div class="eyebrow">
                <span></span> PLAN YOUR CLEANING REQUIREMENT
            </div>

            <h2>Let's understand your <em>space and needs.</em></h2>

            <p>
                Share your property type, approximate size, areas of focus
                and preferred schedule so the business can discuss
                the appropriate service scope with you.
            </p>
        </div>

        <div class="quote-detail-grid">
            <div>
                <i class="fa-solid fa-building"></i>
                <h3>Property Type</h3>
                <p>Home, apartment, office, shop or commercial space.</p>
            </div>

            <div>
                <i class="fa-solid fa-ruler-combined"></i>
                <h3>Space and Layout</h3>
                <p>Approximate area, number of rooms and layout.</p>
            </div>

            <div>
                <i class="fa-solid fa-broom"></i>
                <h3>Cleaning Requirements</h3>
                <p>Specific rooms, surfaces and areas needing attention.</p>
            </div>

            <div>
                <i class="fa-solid fa-calendar-check"></i>
                <h3>Preferred Schedule</h3>
                <p>Your preferred date and convenient time window.</p>
            </div>
        </div>

        <div class="services-bottom-cta">
            <h2>Have a cleaning requirement in Mumbai?</h2>
            <p>Get in touch to discuss the details and request an enquiry.</p>

            <a class="button button-primary"
               href="<?=e(page_url('contact.php'))?>">
                Discuss Your Requirement
                <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>

    </div>
</section>

<?php require __DIR__.'/includes/footer.php'; ?>
