
<?php
require_once __DIR__ . '/../includes/bootstrap.php';

$slug = trim((string)($_GET['slug'] ?? ''));
$services = approved_services();

if ($slug === '' || !isset($services[$slug])) {
    http_response_code(404);
    $pageTitle = 'Service Not Found | ' . $config['business_name'];
    require __DIR__ . '/../includes/header.php';
    ?>
    <section class="section not-found">
        <div class="container">
            <div class="eyebrow"><span></span> SERVICE PAGE</div>
            <h1>This service page is <em>not available.</em></h1>
            <p>Please visit our services page to explore our cleaning solutions.</p>
            <a class="button button-primary" href="<?= e(page_url('services')) ?>">
                Back to services <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>
    </section>
    <?php
    require __DIR__ . '/../includes/footer.php';
    exit;
}

$s = $services[$slug];
$title = $s['title'] ?? 'Cleaning Service';

/*
|--------------------------------------------------------------------------
| Service-specific content for all 12 services
|--------------------------------------------------------------------------
*/

$content = [

    'full-home-deep-cleaning' => [
        'intro' => 'Give your home a detailed cleaning with our full home deep cleaning service in Mumbai. From everyday living areas to commonly overlooked corners, the service focuses on improving the overall cleanliness of your home.',
        'focus' => [
            'Living room and common areas',
            'Bedrooms and accessible surfaces',
            'Kitchen surfaces and selected areas',
            'Bathroom and washroom areas',
            'Doors, switches and reachable fixtures',
            'Dust and dirt in accessible corners'
        ],
        'benefits' => [
            'A more thoroughly cleaned living space',
            'Attention to commonly missed areas',
            'Suitable for different home sizes',
            'A convenient option for periodic cleaning'
        ],
        'process' => [
            'Discuss your home size and cleaning requirements.',
            'Confirm the service scope, quotation and schedule.',
            'Cleaning is carried out according to the agreed scope.',
            'Review the completed work with the service team.'
        ],
        'faqs' => [
            ['How long does full home deep cleaning take?', 'The time depends on the size of your home, its condition and the agreed cleaning scope.'],
            ['Can I book deep cleaning for a flat?', 'Yes. You can enquire about deep cleaning for flats and apartments of different sizes.'],
            ['Should I confirm the cleaning scope before booking?', 'Yes. Discuss the rooms, specific requirements, inclusions and quotation before confirming your booking.']
        ]
    ],

    'sofa-cleaning' => [
        'intro' => 'Sofas are used every day and can collect dust, stains and everyday dirt. Our sofa cleaning service focuses on cleaning sofa surfaces and upholstery according to the material and condition.',
        'focus' => [
            'Sofa seats and backrest surfaces',
            'Armrests and accessible fabric areas',
            'Visible dirt and everyday stains',
            'Cushions, where included in the agreed scope',
            'Material-appropriate cleaning approach'
        ],
        'benefits' => [
            'Helps improve the appearance of your sofa',
            'Addresses everyday surface dirt',
            'Suitable for different sofa configurations',
            'Cleaning approach can be discussed according to fabric type'
        ],
        'process' => [
            'Share the sofa type, size and material.',
            'Discuss stains and the condition of the upholstery.',
            'Confirm the cleaning method and quotation.',
            'Cleaning is completed according to the agreed scope.'
        ],
        'faqs' => [
            ['Can different types of sofas be cleaned?', 'Enquire with the sofa material, design and condition so the suitable cleaning approach can be confirmed.'],
            ['Can sofa stains be removed completely?', 'Results depend on the stain, fabric and how long the stain has been present. Complete removal cannot be guaranteed.'],
            ['Do I need to share sofa photos?', 'Sharing clear photos can help the business understand your sofa and discuss the requirement.']
        ]
    ],

    'carpet-cleaning' => [
        'intro' => 'Carpets can collect dust, dirt and stains through regular use. Our carpet cleaning service focuses on improving carpet cleanliness while considering its material, size and condition.',
        'focus' => [
            'Carpet surface cleaning',
            'Dust and accumulated surface dirt',
            'Visible stains, subject to fabric and stain condition',
            'Edges and accessible carpet areas',
            'Cleaning approach based on carpet material'
        ],
        'benefits' => [
            'Helps refresh the appearance of carpets',
            'Addresses everyday dirt and surface marks',
            'Suitable for different carpet sizes',
            'Cleaning requirements can be assessed beforehand'
        ],
        'process' => [
            'Share the carpet size, material and condition.',
            'Discuss visible stains and cleaning expectations.',
            'Confirm the cleaning method and quotation.',
            'Cleaning is performed according to the agreed scope.'
        ],
        'faqs' => [
            ['Can all carpet materials be cleaned?', 'The suitable cleaning method depends on the carpet material and condition. Confirm this before booking.'],
            ['Can old carpet stains be removed?', 'Old stains may be difficult to remove. Results depend on the stain type, carpet material and previous treatment.'],
            ['Can I enquire about a large carpet?', 'Yes. Share the carpet dimensions and location to discuss the requirement.']
        ]
    ],

    'kitchen-deep-cleaning' => [
        'intro' => 'The kitchen is one of the most frequently used areas of a home. Our kitchen deep cleaning service focuses on cleaning accessible kitchen surfaces and areas where grease, food residue and everyday dirt may accumulate.',
        'focus' => [
            'Kitchen platform and accessible surfaces',
            'Sink and surrounding areas',
            'Exterior surfaces of cabinets',
            'Tiles and accessible wall surfaces',
            'Exterior surfaces of appliances, where agreed',
            'Accessible corners and visible dirt'
        ],
        'benefits' => [
            'Helps improve overall kitchen cleanliness',
            'Focuses on frequently used surfaces',
            'Addresses visible grease and everyday dirt',
            'Scope can be discussed according to kitchen size'
        ],
        'process' => [
            'Share your kitchen size and layout.',
            'Identify areas requiring special attention.',
            'Confirm appliance, cabinet and surface inclusions.',
            'Cleaning is completed according to the agreed scope.'
        ],
        'faqs' => [
            ['Are kitchen cabinets included?', 'Cabinet cleaning requirements and whether interiors are included should be confirmed before booking.'],
            ['Are appliances cleaned?', 'Discuss the appliances you want cleaned and confirm whether their interiors or exteriors are included.'],
            ['Can heavy grease be cleaned?', 'The approach depends on the surface, grease buildup and material. Share details before booking.']
        ]
    ],

    'bathroom-deep-cleaning' => [
        'intro' => 'Bathrooms need regular attention because moisture, soap residue and everyday use can leave surfaces dirty. Our bathroom deep cleaning service focuses on the agreed bathroom surfaces and fixtures.',
        'focus' => [
            'Floor and accessible wall tiles',
            'Washbasin and surrounding surfaces',
            'Toilet exterior and agreed areas',
            'Shower area and accessible fittings',
            'Taps and bathroom fixtures',
            'Visible soap residue and dirt'
        ],
        'benefits' => [
            'Helps improve bathroom cleanliness',
            'Focuses on frequently used fixtures',
            'Addresses visible surface buildup',
            'Suitable for residential bathroom spaces'
        ],
        'process' => [
            'Share the number and size of bathrooms.',
            'Discuss the condition and areas requiring attention.',
            'Confirm the cleaning scope and quotation.',
            'Cleaning is carried out according to the agreed requirements.'
        ],
        'faqs' => [
            ['Can hard water stains be removed?', 'Results depend on the severity of the deposits and the surface material.'],
            ['Are bathroom tiles included?', 'Accessible tiles can be discussed as part of the cleaning scope. Confirm the exact areas before booking.'],
            ['Can I book cleaning for multiple bathrooms?', 'Yes. Share the number of bathrooms and their approximate sizes when enquiring.']
        ]
    ],

    'floor-cleaning-polishing' => [
        'intro' => 'Floors experience regular foot traffic and can gradually lose their clean appearance. Our floor cleaning and polishing service is intended for floor surfaces that need attention based on their material and condition.',
        'focus' => [
            'Floor surface cleaning',
            'Removal of everyday surface dirt',
            'Accessible edges and corners',
            'Floor material assessment',
            'Polishing requirements, where suitable and agreed'
        ],
        'benefits' => [
            'Helps improve floor appearance',
            'Considers the type of floor material',
            'Suitable for selected residential and commercial spaces',
            'Cleaning and polishing requirements can be discussed separately'
        ],
        'process' => [
            'Share the floor type and approximate area.',
            'Discuss scratches, stains and surface condition.',
            'Confirm whether cleaning, polishing or both are required.',
            'Proceed according to the agreed method and quotation.'
        ],
        'faqs' => [
            ['Can marble floors be polished?', 'Marble polishing requirements should be assessed according to the floor condition and finish.'],
            ['Is polishing suitable for every floor?', 'No. The appropriate method depends on the floor material and existing finish.'],
            ['Can I enquire for a large floor area?', 'Yes. Share the approximate square footage and floor type for an enquiry.']
        ]
    ],

    'office-deep-cleaning' => [
        'intro' => 'A clean office helps maintain a comfortable and organised workplace. Our office deep cleaning service focuses on agreed work areas, shared spaces and accessible surfaces.',
        'focus' => [
            'Workstations and accessible desk surfaces',
            'Meeting rooms and common areas',
            'Reception and waiting areas',
            'Floor and accessible surface cleaning',
            'Washroom areas, where included',
            'Frequently touched accessible surfaces'
        ],
        'benefits' => [
            'Supports a cleaner workplace',
            'Suitable for different office layouts',
            'Cleaning scope can be planned around office requirements',
            'Options can be discussed for periodic cleaning'
        ],
        'process' => [
            'Share the office location, size and layout.',
            'Discuss workstations and areas to be cleaned.',
            'Agree on the schedule and cleaning scope.',
            'Complete the work according to the agreed plan.'
        ],
        'faqs' => [
            ['Can office cleaning be scheduled outside working hours?', 'Share your preferred timing so availability can be discussed.'],
            ['Can multiple office floors be cleaned?', 'Yes. Share the number of floors and approximate area when requesting a quotation.'],
            ['Can cleaning be arranged periodically?', 'Discuss your preferred frequency and requirements with the business.']
        ]
    ],

    'commercial-cleaning' => [
        'intro' => 'Commercial properties have different cleaning requirements depending on their size, layout and daily activities. Our commercial cleaning service can be discussed for business premises and other commercial spaces.',
        'focus' => [
            'Common and shared areas',
            'Floors and accessible surfaces',
            'Reception and customer-facing spaces',
            'Washroom areas, where agreed',
            'Work and activity areas',
            'Other agreed commercial cleaning requirements'
        ],
        'benefits' => [
            'Cleaning scope based on the property',
            'Suitable for different commercial environments',
            'Options for one-time cleaning enquiries',
            'Scheduling discussed according to site requirements'
        ],
        'process' => [
            'Share the property type and location.',
            'Discuss the approximate area and cleaning needs.',
            'Confirm the work scope, schedule and quotation.',
            'Cleaning is performed according to the agreed plan.'
        ],
        'faqs' => [
            ['Which commercial spaces can I enquire about?', 'Share the type of property and cleaning requirement so the business can assess it.'],
            ['Can large commercial areas be cleaned?', 'Yes. Provide the approximate area and site details for an assessment.'],
            ['Can I request a site inspection?', 'Contact the business to discuss whether a site visit is required for your quotation.']
        ]
    ],

    'residential-cleaning' => [
        'intro' => 'Our residential cleaning service is intended for homes and living spaces that need cleaning according to their layout, size and requirements. Discuss your cleaning priorities to determine the suitable scope.',
        'focus' => [
            'Living rooms and common spaces',
            'Bedrooms and accessible surfaces',
            'Kitchen areas, where included',
            'Bathroom areas, where included',
            'Floor and surface cleaning',
            'Other agreed residential areas'
        ],
        'benefits' => [
            'Suitable for different residential properties',
            'Cleaning scope based on your home',
            'Options can be discussed for specific areas',
            'Convenient enquiry for household cleaning needs'
        ],
        'process' => [
            'Share your property type and location.',
            'Discuss the rooms and areas to be cleaned.',
            'Confirm the service scope and quotation.',
            'Cleaning is completed according to the agreed requirements.'
        ],
        'faqs' => [
            ['Is residential cleaning available for apartments?', 'You can enquire about cleaning for apartments and other residential properties.'],
            ['Can I select specific rooms?', 'Yes. Share the rooms and areas you want included in the enquiry.'],
            ['Is residential cleaning different from deep cleaning?', 'The scope and level of cleaning can differ. Discuss your requirements to identify the suitable service.']
        ]
    ],

    'water-tank-cleaning' => [
        'intro' => 'Water storage tanks require periodic attention because dirt and sediment may accumulate over time. Our water tank cleaning service focuses on cleaning the tank according to its type, size and condition.',
        'focus' => [
            'Water tank interior cleaning',
            'Removal of accumulated dirt and sediment',
            'Cleaning of accessible internal surfaces',
            'Tank condition and access assessment',
            'Cleaning requirements based on tank capacity and type'
        ],
        'benefits' => [
            'Helps maintain a cleaner water storage tank',
            'Addresses accumulated dirt and sediment',
            'Suitable requirements can be discussed for different tank sizes',
            'Cleaning scope confirmed before work begins'
        ],
        'process' => [
            'Share the tank type, approximate capacity and location.',
            'Discuss access, current condition and cleaning requirements.',
            'Confirm the cleaning method, scope and quotation.',
            'Tank cleaning is carried out according to the agreed plan.'
        ],
        'faqs' => [
            ['Can overhead water tanks be cleaned?', 'Share the tank type, location and access details to confirm the requirement.'],
            ['Can underground water tanks be cleaned?', 'Enquire with the tank size, access details and location so the scope can be assessed.'],
            ['How often should a water tank be cleaned?', 'The appropriate cleaning frequency depends on tank usage, condition and maintenance requirements.'],
            ['Do you clean tanks of different capacities?', 'Share the approximate tank capacity when enquiring so the service requirement can be discussed.']
        ]
    ],

    'upholstery-cleaning' => [
        'intro' => 'Upholstered furniture can collect dust, everyday dirt and stains through regular use. Our upholstery cleaning service focuses on suitable fabric-covered furniture and surfaces according to their material and condition.',
        'focus' => [
            'Fabric-covered furniture surfaces',
            'Accessible upholstered seating',
            'Visible dirt and surface stains',
            'Cushions and fabric sections, where agreed',
            'Material-specific cleaning requirements'
        ],
        'benefits' => [
            'Helps refresh the appearance of upholstery',
            'Focuses on everyday surface dirt',
            'Suitable for selected upholstered furniture',
            'Cleaning approach discussed according to material'
        ],
        'process' => [
            'Share the furniture type and upholstery material.',
            'Discuss stains, size and current condition.',
            'Confirm the suitable cleaning method and quotation.',
            'Cleaning is completed according to the agreed scope.'
        ],
        'faqs' => [
            ['Which furniture can be considered for upholstery cleaning?', 'Share the furniture type and material so the business can assess the requirement.'],
            ['Can delicate fabrics be cleaned?', 'Delicate materials require assessment before selecting a cleaning approach.'],
            ['Can old stains be removed?', 'Results depend on the stain type, fabric and how long it has been present.']
        ]
    ],

    'specialized-cleaning' => [
        'intro' => 'Some cleaning requirements need attention beyond routine home or office cleaning. Our specialized cleaning service is intended for specific cleaning needs that can be discussed and assessed individually.',
        'focus' => [
            'Specific cleaning requirements',
            'Areas requiring additional attention',
            'Property-specific cleaning concerns',
            'Suitable surface and material considerations',
            'Other requirements assessed individually'
        ],
        'benefits' => [
            'A service enquiry for specific cleaning needs',
            'Requirements discussed before confirmation',
            'Scope based on the property and condition',
            'Quotation based on the agreed work'
        ],
        'process' => [
            'Explain the specific cleaning problem.',
            'Share photographs and property details if available.',
            'Discuss feasibility, scope and quotation.',
            'Proceed after the service requirements are agreed.'
        ],
        'faqs' => [
            ['What comes under specialized cleaning?', 'It covers specific cleaning requirements that need to be discussed individually with the business.'],
            ['Can I share photos of the cleaning area?', 'Yes. Photos can help explain the condition and the type of cleaning required.'],
            ['Is a quotation available before booking?', 'Contact the business with your requirements to discuss the quotation before confirming the service.']
        ]
    ]
];

$details = $content[$slug] ?? null;

if (!$details) {
    http_response_code(404);
    $pageTitle = 'Service Not Found | ' . $config['business_name'];
    require __DIR__ . '/../includes/header.php';
    ?>
    <section class="section not-found">
        <div class="container">
            <h1>Service content is unavailable.</h1>
            <a class="button button-primary" href="<?= e(page_url('services')) ?>">Back to services</a>
        </div>
    </section>
    <?php
    require __DIR__ . '/../includes/footer.php';
    exit;
}

/*
|--------------------------------------------------------------------------
| Service images
|--------------------------------------------------------------------------
*/

$serviceImages = [
    'full-home-deep-cleaning' => 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=1600&q=85',
    'sofa-cleaning' => 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1600&q=85',
    'carpet-cleaning' => 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1600&q=85',
    'kitchen-deep-cleaning' => 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1600&q=85',
    'bathroom-deep-cleaning' => 'https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=1600&q=85',
    'floor-cleaning-polishing' => 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=85',
    'office-deep-cleaning' => 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1600&q=85',
    'commercial-cleaning' => 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=1600&q=85',
    'residential-cleaning' => 'https://images.unsplash.com/photo-1600210492493-0946911123ea?auto=format&fit=crop&w=1600&q=85',
    'water-tank-cleaning' => 'https://www.pluspoint.ae/uploads/Blogs/blog_1304724368.webp',
    'upholstery-cleaning' => 'https://images.unsplash.com/photo-1550254478-ead40cc54513?auto=format&fit=crop&w=1600&q=85',
    'specialized-cleaning' => 'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&w=1600&q=85'
];

$image = $serviceImages[$slug] ?? ($s['image'] ?? '');

$pageTitle = $title . ' in Mumbai | ' . $config['business_name'];
$pageDescription = $details['intro'];

require __DIR__ . '/../includes/header.php';
?>

<!-- HERO -->
<section class="service-detail-hero">
    <div class="service-detail-hero-image"
         style="background-image:url('<?= e($image) ?>')"></div>
    <div class="service-detail-hero-shade"></div>

    <div class="container service-detail-hero-content">
        <div class="eyebrow eyebrow-light">
            <span></span> PROFESSIONAL CLEANING SERVICES
        </div>

        <h1><?= e($title) ?></h1>

        <p><?= e($details['intro']) ?></p>

        <div class="service-detail-actions">
            <a class="button button-primary" href="<?= e(page_url('contact.php')) ?>">
                Get a Free Enquiry <i class="fa-solid fa-arrow-right"></i>
            </a>
            <a class="button button-outline" href="<?= e(page_url('services')) ?>">
                All Services
            </a>
        </div>

        <div class="breadcrumbs">
            <a href="<?= e(site_url()) ?>">Home</a>
            <i class="fa-solid fa-angle-right"></i>
            <a href="<?= e(page_url('services')) ?>">Services</a>
            <i class="fa-solid fa-angle-right"></i>
            <span><?= e($title) ?></span>
        </div>
    </div>
</section>

<!-- INTRODUCTION -->
<section class="section service-detail-intro">
    <div class="container">
        <div class="service-detail-intro-grid">
            <div>
                <div class="eyebrow"><span></span> ABOUT THIS SERVICE</div>
                <h2>Professional care for a <em>cleaner space.</em></h2>
            </div>

            <div class="service-detail-intro-copy">
                <p><?= e($details['intro']) ?></p>
                <p>
                    We discuss your location, property details and cleaning
                    requirements before confirming the service scope and quotation.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- SERVICE SCOPE -->
<section class="section service-detail-scope">
    <div class="container">
        <div class="section-heading">
            <div class="eyebrow"><span></span> SERVICE SCOPE</div>
            <h2>What this service <em>covers.</em></h2>
            <p>
                The following areas describe the key cleaning requirements
                for this service. Final inclusions are confirmed before booking.
            </p>
        </div>

        <div class="service-detail-focus-grid">
            <?php foreach ($details['focus'] as $item): ?>
                <div class="service-detail-focus-card">
                    <span class="service-detail-check">
                        <i class="fa-solid fa-check"></i>
                    </span>
                    <h3><?= e($item) ?></h3>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- BENEFITS -->
<section class="section service-detail-benefits">
    <div class="container">
        <div class="service-detail-benefits-grid">
            <div class="service-detail-benefits-heading">
                <div class="eyebrow"><span></span> WHY CHOOSE THIS SERVICE</div>
                <h2>A cleaner space starts with the <em>right attention.</em></h2>
                <p>
                    Every property has different cleaning needs. Discuss your
                    requirements with us to understand the suitable service scope.
                </p>
            </div>

            <div class="service-detail-benefit-list">
                <?php foreach ($details['benefits'] as $benefit): ?>
                    <div class="service-detail-benefit-item">
                        <i class="fa-solid fa-circle-check"></i>
                        <span><?= e($benefit) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- PROCESS -->
<section class="section service-detail-process">
    <div class="container">
        <div class="section-heading centered">
            <div class="eyebrow"><span></span> HOW IT WORKS</div>
            <h2>Simple steps to get your <em>space cleaned.</em></h2>
        </div>

        <div class="service-detail-process-grid">
            <?php foreach ($details['process'] as $index => $step): ?>
                <div class="service-detail-process-card">
                    <span class="service-detail-step-number">
                        <?= sprintf('%02d', $index + 1) ?>
                    </span>
                    <p><?= e($step) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- FAQ -->
<section class="section service-detail-faq">
    <div class="container">
        <div class="section-heading centered">
            <div class="eyebrow"><span></span> FREQUENTLY ASKED QUESTIONS</div>
            <h2>Questions about <?= e($title) ?>?</h2>
            <p>Find answers to common questions before making an enquiry.</p>
        </div>

        <div class="service-detail-faq-list">
            <?php foreach ($details['faqs'] as $index => $faq): ?>
                <details class="service-detail-faq-item" <?= $index === 0 ? 'open' : '' ?>>
                    <summary>
                        <span><?= e($faq[0]) ?></span>
                        <i class="fa-solid fa-plus"></i>
                    </summary>
                    <div class="service-detail-faq-answer">
                        <p><?= e($faq[1]) ?></p>
                    </div>
                </details>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="section service-detail-cta">
    <div class="container">
        <div class="service-detail-cta-box">
            <div class="eyebrow eyebrow-light">
                <span></span> READY TO GET STARTED?
            </div>

            <h2>Looking for <?= e($title) ?> in Mumbai?</h2>

            <p>
                Tell us about your cleaning requirement, property location
                and preferred schedule. Get in touch to discuss the service.
            </p>

            <div class="service-detail-actions">
                <a class="button button-primary" href="<?= e(page_url('contact.php')) ?>">
                    Make an Enquiry <i class="fa-solid fa-arrow-right"></i>
                </a>
                <a href="<?= e(site_url('services')) ?>" class="text-link">
    Explore All Services
    <i class="fa-solid fa-arrow-right"></i>
</a>
            </div>
        </div>
    </div>
</section>

<?php require __DIR__ . '/../includes/footer.php'; ?>
